return {
    "williamboman/mason.nvim",
    version = 'v1.*',
    dependencies = {
	{
	    "williamboman/mason-lspconfig.nvim",
	    version = 'v1.*',
	},
	"WhoIsSethDaniel/mason-tool-installer.nvim",
    },
    config = function()
	-- import mason
	local mason = require("mason")

	-- import mason-lspconfig
	local mason_lspconfig = require("mason-lspconfig")
	local mason_tool_installer = require("mason-tool-installer")

	-- enable mason and configure icons
	mason.setup({
	    ui = {
		icons = {
		    package_installed = "✓",
		    package_pending = "➜",
		    package_uninstalled = "✗",
		},
		border = "rounded",
	    },
	})

	mason_lspconfig.setup({
	    -- list of servers for mason to install
	    ensure_installed = {
		"lua_ls",
		"pyright",
		"jsonls",
	    },
	})

	mason_tool_installer.setup({
	    ensure_installed = {
		"prettier", -- prettier formatter
		"stylua", -- lua formatter
		"isort", -- python formatter
		"black", -- python formatter
		"pylint",
		"eslint_d",
		"marksman" -- markdown
	    },
	})
    end,
}
